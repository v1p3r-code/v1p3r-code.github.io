function asyncTimeout(timeout) {
    return new Promise(resolve => setTimeout(resolve, timeout));
}

async function asyncExecuteScript(tabId, details) {
    var result = await getExecuteScriptPromise(tabId, details)
        .then((result) => {return result;})
        .catch((ex) => {logRuntimeException("asyncExecuteScript = " + ex.message);});
    return result;   
}
const getExecuteScriptPromise = (...args) => {
    return new Promise((resolve, reject) => {
        chrome.tabs.executeScript(...args, () => {
            let lastError = chrome.runtime.lastError;
            if (lastError) return reject(lastError);
            resolve(true);
        });
    });
}

async function asyncGetTab(tabId) {
    var result = await getTabPromise(tabId).then((tabObj) => {return tabObj;})
        .catch((ex) => {logRuntimeException("asyncGetTab = " + ex.message);});
    return result;
}
const getTabPromise = (...args) => {
    return new Promise((resolve, reject) => {
        chrome.tabs.get(...args, (tabObj, data) => {
            let lastError = chrome.runtime.lastError;
            if (lastError) return reject(lastError);
            resolve(data = tabObj);
        });
    });
}

async function asyncGetActiveTab() {
    var result = await getActiveTabPromise().then((activeTabObj) => activeTabObj)
        .catch((ex) => {logRuntimeException("asyncGetActiveTab = " + ex.message);});
    return result;
}
const getActiveTabPromise = () => {
    return new Promise((resolve, reject) => {
        chrome.tabs.query(
            {active: true, currentWindow: true}, 
            (tabs, data) => { 
                let lastError = chrome.runtime.lastError;
                if (lastError) return reject(lastError);
                resolve(data = tabs[0]); 
            });
    })
}

