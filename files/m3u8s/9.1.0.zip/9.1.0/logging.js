var stealthRelease = true;
var devDebugging = false;
var devVerboseLog = false;
var logRuntimeErrors = false;
var alertRuntimeErrors = false;
var squelchRuntimeErrors = true;
var logRuntimeExceptions = false;
var alertRuntimeExceptions = false;
var squelchRuntimeExceptions = true;

function checkLastError(caller) {
    var lastError = chrome.runtime.lastError;
    if (lastError) logRuntimeError("checkLastError = " + lastError.message);
    return lastError;
};

function devLog(...args) {
    if (!stealthRelease) console.log(...args);
}
function devInfo(...args) {
    if (!stealthRelease) console.info(...args);
}
function devDebug(...args) {
    if (devDebugging && !stealthRelease) console.info(...args);
}
function devVerbose(...args) {
    if (devVerboseLog && !stealthRelease) console.debug(...args);
}

function logRuntimeError(...args) {
    if (!stealthRelease) {
        if (logRuntimeErrors) {
            console.groupCollapsed("ERROR: " + args[0] + " ...");
            console.log(...args); console.trace();
            console.groupEnd();
        }
        if (alertRuntimeErrors) alertRuntimeError(...args);
    }
}
function alertRuntimeError(...args) {
    if (alertRuntimeErrors && !stealthRelease) {
        alert("ERROR: " + args.join(' '));
    }
}

function logRuntimeException(...args) {
    if (!stealthRelease) {
        if (logRuntimeExceptions) {
            console.groupCollapsed("ERROR: (Exception) " + args[0] + " ...");
            console.log(...args); console.trace();
            console.groupEnd();
        }
        if (alertRuntimeExceptions) alertRuntimeException(...args);
    }
}
function alertRuntimeException(...args) {
    if (alertRuntimeExceptions && !stealthRelease) {
        alert("ERROR (Exception): " + args.join(' '));
    }
}


window.addEventListener('error', function(event) {
    logRuntimeError("window error event =", event);
    if (squelchRuntimeErrors || stealthRelease) event.preventDefault();
});

window.addEventListener('unhandledrejection', function (event) {
    logRuntimeException("window unhandledrejection event =", event);
    if (squelchRuntimeExceptions || stealthRelease) event.preventDefault();
});
